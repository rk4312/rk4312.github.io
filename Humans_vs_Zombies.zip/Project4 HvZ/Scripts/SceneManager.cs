﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManager : MonoBehaviour
{
    // Lists to hold all agents in the scene
    public List<GameObject> listOfHumans;
    public List<GameObject> listOfZombies;
    public List<GameObject> listOfObstacles;

    // Prefabs of agents
    public GameObject humanPrefab;
    public GameObject zombiePrefab;
    public GameObject obstaclePrefab;

    // Float for distance between zombie and human
    public float distanceBetweenHandZ;
    public int indexToSeek;

    // Number of humans in the scene
    public int numberOfHumans;
    public int numberOfZombies;
    public int numberOfObstacles;

    // Counts number of medical kits picked up. Human will spawn once enough are collected
    public int suppliesCollected;

    public bool debugLinesToggle;

    // Start is called before the first frame update
    void Start()
    {
        debugLinesToggle = false;

        // Instantiates humans to a random position on the floor based on the public int number of humans
        for (int i = 0; i < numberOfHumans; i++)
        {
            Vector3 randPosH = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfHumans.Add(Instantiate(humanPrefab, randPosH, Quaternion.identity));
            listOfHumans[i].GetComponent<Human>().vehiclePosition = randPosH;
        }

        // Instantiates zombies to a random position on the floor based on the public int number of zombies
        for (int i = 0; i < numberOfZombies; i++)
        {
            Vector3 randPosZ = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfZombies.Add(Instantiate(zombiePrefab, randPosZ, Quaternion.identity));
            listOfZombies[i].GetComponent<Zombie>().vehiclePosition = randPosZ;
        }

        // Instantiates obstacles to a random position on the floor based on the public int number of obstacles
        for (int i = 0; i < numberOfObstacles; i++)
        {
            Vector3 randPosZ = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfObstacles.Add(Instantiate(obstaclePrefab, randPosZ, Quaternion.identity));
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Loops through all zombies and humans and checks for collision
        for (int i = 0; i < listOfZombies.Count; i++)
        {
            if (listOfHumans.Count > 0)
            {
                for (int j = 0; j < listOfHumans.Count; j++)
                {
                    // If there is a collision, the human is destroyed and removed from the list and a new zombie is created in its stead
                    if (CircleCollision(listOfZombies[i], listOfHumans[j]))
                    {
                        Debug.Log("collision detected");
                        Vector3 positionOfCollision = listOfHumans[j].transform.position;
                        Vector3 positionOfNewZombie = new Vector3(positionOfCollision.x, 0, positionOfCollision.z);
                        listOfZombies.Add(Instantiate(zombiePrefab, positionOfNewZombie, Quaternion.identity));
                        listOfZombies[listOfZombies.Count - 1].GetComponent<Zombie>().vehiclePosition = positionOfNewZombie;
                        Destroy(listOfHumans[j]);
                        listOfHumans.RemoveAt(j);
                        listOfZombies[i].GetComponent<Zombie>().human = null;
                        j--;
                    }
                }
            }
            else
            {
                listOfZombies[i].GetComponent<Zombie>().human = null;
            }
        }

        // Loops through all the zombies and determines which human is closest to each of them and 
        // passes that human onto the individual script to call seek on
        for (int i = 0; i < listOfZombies.Count; i++)
        {
            distanceBetweenHandZ = Mathf.Infinity; // Instantiating distance as a large number to be reassigned when the respective code runs
            //Debug.Log("zombies count" + listOfZombies.Count);
            if (listOfHumans.Count > 0)
            {
                for (int j = 0; j < listOfHumans.Count; j++)
                {
                    //Debug.Log("humans count" + listOfHumans.Count);
                    // Loops through all humans and determines which one is closest
                    if (Vector3.Distance(listOfZombies[i].GetComponent<Zombie>().vehiclePosition, listOfHumans[j].GetComponent<Human>().vehiclePosition) < distanceBetweenHandZ)
                    {
                        distanceBetweenHandZ = Vector3.Distance(listOfZombies[i].GetComponent<Zombie>().vehiclePosition, listOfHumans[j].GetComponent<Human>().vehiclePosition);
                        indexToSeek = j;
                    }
                }
                // Passes on the closest human to the individual script for it to call seek on
                listOfZombies[i].GetComponent<Zombie>().human = listOfHumans[indexToSeek];
            }
            else
            {
                listOfZombies[i].GetComponent<Zombie>().human = null;
            }
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            debugLinesToggle = !debugLinesToggle;
        }

        // Spawns a new human in a random position if enough supplies are collected
        if (suppliesCollected >= 3)
        {
            Vector3 randPosH = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfHumans.Add(Instantiate(humanPrefab, randPosH, Quaternion.identity));
            listOfHumans[listOfHumans.Count - 1].GetComponent<Human>().vehiclePosition = randPosH;
            suppliesCollected = 0;
        }

        // Spawns human on h button press
        if (Input.GetKeyDown(KeyCode.H))
        {
            Vector3 randPosH = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfHumans.Add(Instantiate(humanPrefab, randPosH, Quaternion.identity));
            listOfHumans[listOfHumans.Count - 1].GetComponent<Human>().vehiclePosition = randPosH;
        }

        // Spawns zombie on z button press
        if (Input.GetKeyDown(KeyCode.Z))
        {
            Vector3 randPosZ = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
            listOfZombies.Add(Instantiate(zombiePrefab, randPosZ, Quaternion.identity));
            listOfZombies[listOfZombies.Count - 1].GetComponent<Zombie>().vehiclePosition = randPosZ;
        }
    }

    public bool CircleCollision(GameObject collider1, GameObject collider2)
    {
        // Stores the sprite renderer of both colliders
        MeshRenderer collider1MR = collider1.transform.GetChild(0).GetComponent<MeshRenderer>();
        MeshRenderer collider2MR = collider2.transform.GetChild(0).GetComponent<MeshRenderer>();

        // Stores the position of both colliders
        Vector3 collider1Pos = collider1.transform.position;
        Vector3 collider2Pos = collider2.transform.position;

        // Radii of both colliders
        float collider1Radius;
        float collider2Radius;

        // Declares the radius for both colliders depending on which extent is larger
        if (collider1MR.bounds.extents.x > collider1MR.bounds.extents.z)
            collider1Radius = collider1MR.bounds.extents.x;
        else
            collider1Radius = collider1MR.bounds.extents.z;

        if (collider2MR.bounds.extents.x > collider2MR.bounds.extents.z)
            collider2Radius = collider2MR.bounds.extents.x;
        else
            collider2Radius = collider2MR.bounds.extents.z;

        // Stores the distance between the two colliders
        float distance = Vector3.Distance(collider1Pos, collider2Pos);

        if (Mathf.Pow(collider1Radius + collider2Radius, 2) > Mathf.Pow(distance, 2))
            return true;
        else
            return false;
    }
}
