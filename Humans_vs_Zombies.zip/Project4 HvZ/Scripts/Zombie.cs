﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : Vehicle
{
    public GameObject human;
    public int wanderTimer;

    // Start is called before the first frame update
    void Start()
    {
        base.Start();
    }

    // Update is called once per frame
    void Update()
    {
        base.Update();
    }

    public override void CalcSteeringForces()
    {
        Vector3 ultimateForce = Vector3.zero;

        // Seeks human always
        ultimateForce += Pursue(human);
        
        if (Vector3.Distance(new Vector3(0, 0.55f, 0), vehiclePosition) > 18)
        {
            // Calls seek on center if vehicle is a certain distance away to enforce boundaries 
            // (seek center force multiplied by distance. Distance is divided by an arbitrary number to ensure reasonable balance of forces)
            ultimateForce += (Seek(new Vector3(0, 0.55f, 0)) * (Vector3.Distance(vehiclePosition, new Vector3(0, 0.55f, 0)) / 50));
        }

        // If all humans are dead, wander is called periodically
        if (human == null)
        {
            wanderTimer++;
            if (wanderTimer >= 12)
            {
                ultimateForce += Wander();
                wanderTimer = 0;
            }
        }

        // Calls obstacle avoidance
        for (int i = 0; i < GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfObstacles.Count; i++)
            ultimateForce += ObstacleAvoidance(GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfObstacles);

        // Calls seperation
        ultimateForce += Seperation(GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfZombies, 4);

        // Normalizes ultimate force
        ultimateForce.Normalize();

        // Scales ultimate force by max speed
        ultimateForce *= maxSpeed;

        // Applies ultimate force
        ApplyForce(ultimateForce);
    }

    // Debug Lines method
    void OnRenderObject()
    {
        if (GameObject.Find("SceneManager").GetComponent<SceneManager>().debugLinesToggle)
        {
            Debug.Log("openGL lines called");
            // Sets Material for forward vector line
            greenMat.SetPass(0);

            // Begins drawing lines
            GL.Begin(GL.LINES);

            // Starting point
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));

            // End point
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + transform.forward * 2);

            // Ends draw
            GL.End();

            // Sets Material for right vector line
            blueMat.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + transform.right * 2);
            GL.End();

            if (human != null)
            {
                // Sets Material for line to pursuing zombie
                blackMat.SetPass(0);
                GL.Begin(GL.LINES);
                GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));
                GL.Vertex(new Vector3(human.transform.position.x, 2.5f, human.transform.position.z));
                GL.End();
            }

            // Sets material for future position line
            redMat.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + (velocity * 3.5f));
            GL.End();
        }
    }
}
