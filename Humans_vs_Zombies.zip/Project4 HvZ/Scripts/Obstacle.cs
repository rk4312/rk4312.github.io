﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float obstacleRadius;
    
    // Start is called before the first frame update
    void Start()
    {
        MeshRenderer obstacleMR = this.GetComponent<MeshRenderer>();

        // Declares the radius for the obstacle depending on which extent is larger
        if (obstacleMR.bounds.extents.x > obstacleMR.bounds.extents.z)
            obstacleRadius = obstacleMR.bounds.extents.x;
        else
            obstacleRadius = obstacleMR.bounds.extents.z;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
