﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Vehicle : MonoBehaviour
{
    // Vectors necessary for force-based movement
    public Vector3 vehiclePosition;
    public Vector3 acceleration;
    public Vector3 direction;
    public Vector3 velocity;

    // Floats
    public float mass;
    public float maxSpeed;
    public float safeDistance; // Safe distance for obstacle avoidance code

    // Materials for debug lines
    public Material blackMat;
    public Material redMat;
    public Material greenMat;
    public Material blueMat;
    public Material purpleMat;

    // Field for mesh renderer and radius
    public MeshRenderer vehicleMR;
    public float vehicleRadius;

    // Start is called before the first frame update
    public void Start()
    {
        //vehicleMR = gameObject.GetComponent<MeshRenderer>();
        vehicleMR = transform.GetChild(0).GetComponent<MeshRenderer>();
        // Sets the radius for the vehicle depending on which extent is larger
        if (vehicleMR.bounds.extents.x > vehicleMR.bounds.extents.z)
            vehicleRadius = vehicleMR.bounds.extents.x;
        else
            vehicleRadius = vehicleMR.bounds.extents.z;
    }

    // Update is called once per frame
    public void Update()
    {
        velocity += acceleration * Time.deltaTime;
        vehiclePosition += velocity * Time.deltaTime;
        direction = velocity.normalized;
        acceleration = Vector3.zero;
        transform.position = vehiclePosition;

        CalcSteeringForces();

        transform.forward = direction;
    }

    // ApplyForce
    // Receive an incoming force, divide by mass, and apply to the cumulative accel vector
    public void ApplyForce(Vector3 force)
    {
        acceleration += force / mass;
    }

    // SEEK METHOD
    // All Vehicles have the knowledge of how to seek
    // They just may not be calling it all the time
    /// <summary>
    /// Seek
    /// </summary>
    /// <param name="targetPosition">Vector3 position of desired target</param>
    /// <returns>Steering force calculated to seek the desired target</returns>
    public Vector3 Seek(Vector3 targetPosition)
    {
        // Step 1: Find DV (desired velocity)
        // TargetPos - CurrentPos
        Vector3 desiredVelocity = targetPosition - vehiclePosition;

        // Setting the y component of the desired velocity vector to 0
        // since we dont need any movement in the y direction
        desiredVelocity.y = 0;

        // Step 2: Scale vel to max speed
        // desiredVelocity = Vector3.ClampMagnitude(desiredVelocity, maxSpeed);
        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        // Step 3:  Calculate seeking steering force
        Vector3 seekingForce = desiredVelocity - velocity;

        // Step 4: Return force
        return seekingForce;
    }

    /// <summary>
    /// Overloaded Seek
    /// </summary>
    /// <param name="target">GameObject of the target</param>
    /// <returns>Steering force calculated to seek the desired target</returns>
    public Vector3 Seek(GameObject target)
    {
        return Seek(target.transform.position);
    }

    // Flee method. Uses most of seek method code with one difference; desired velocity has opposite direction
    public Vector3 Flee(Vector3 targetPosition)
    {
        Vector3 desiredVelocity = vehiclePosition - targetPosition;

        // Setting the y component of the desired velocity vector to 0
        // since we dont need any movement in the y direction
        desiredVelocity.y = 0;

        desiredVelocity.Normalize();
        desiredVelocity = desiredVelocity * maxSpeed;

        return desiredVelocity - velocity;
    }

    // Flee method that takes a gameobject as a parameter instead of a vector3
    public Vector3 Flee(GameObject target)
    {
        return Flee(target.transform.position);
    }

    // Method to apply friction that accepts a float and produces a vector opposite 
    // to the current velocity and scales it by that coefficient
    public void ApplyFriction(float coeff)
    {
        Vector3 friction = velocity * -1;
        friction.Normalize();
        friction = friction * coeff;
        acceleration += friction;
    }

    // Abstract method that must be overridden by children classes
    public abstract void CalcSteeringForces();

    // Method for Obstacle Avoidance that takes in a list of obstacles and returns an ultimate force
    public Vector3 ObstacleAvoidance(List<GameObject> listOfObstacles)
    {
        Vector3 finalForce = Vector3.zero;
        // Loops through all obstacles and determines if it needs to be avoided
        for (int i = 0; i < listOfObstacles.Count; i++)
        {
            Vector3 vecToCenter = listOfObstacles[i].transform.position - vehiclePosition;

            // Determines if obstacle is in front
            if (Vector3.Dot(gameObject.transform.forward, vecToCenter) >= 0)
            {
                // Determines if obstacle is within safe distance
                if (vecToCenter.magnitude < safeDistance)
                {
                    // Determines whether the absolute value of the dot product of the right vector with the obstacle center
                    // is greater than the sum of their radii. If it is then there's no need to avoid the obstacle
                    if (Mathf.Abs(Vector3.Dot(gameObject.transform.right, vecToCenter)) <
                        (vehicleRadius + listOfObstacles[i].GetComponent<Obstacle>().obstacleRadius))
                    {
                        // Now we need to determine if the obstacle is to the right or left of the vehicle
                        if (Vector3.Dot(gameObject.transform.right, vecToCenter) >= 0)
                            finalForce += (-transform.right * 10); // Dodge left if dot product is positive
                        else
                            finalForce += (transform.right * 10); // Dodge right if dot product is negative
                    }
                }
            }
        }
        if (finalForce.magnitude > 0)
            Debug.Log("obstacle avoidance force = " + finalForce);

        return finalForce;
    }

    // Method to implement seperation
    public Vector3 Seperation(List<GameObject> listOfSimilarAgents, float seperationDistance)
    {
        // Declare a vector and add to it if conditions are met
        Vector3 seperationForce = Vector3.zero;

        // Loops through the passed in list
        for (int i = 0; i < listOfSimilarAgents.Count; i++)
        {
            // Stores distance between agents
            float distanceBetweenAgents = Vector3.Distance(listOfSimilarAgents[i].transform.position, vehiclePosition);
            
            // If distance is less than a certain float then apply a flee force inversely proportionate to the distance
            if (distanceBetweenAgents != 0 && distanceBetweenAgents < seperationDistance)
            {
                seperationForce += (Flee(listOfSimilarAgents[i]) * (1 / distanceBetweenAgents));
            }
        }
        return seperationForce;
    }

    // Pursue method
    public Vector3 Pursue(GameObject targetObj)
    {
        if (targetObj != null)
        {
            // Calculating the future position of the target object
            Vector3 targetPosition = targetObj.transform.position + targetObj.GetComponent<Vehicle>().velocity;

            // Draws a debug line to future position
            Debug.DrawLine(vehiclePosition, targetPosition, Color.green);

            // Call and return seek on the future position of target object
            return Seek(targetPosition);
        }
        else
            return Vector3.zero;
    }

    // Evade method
    public Vector3 Evade(GameObject targetObj)
    {
        // Calculating the future position of the target object
        Vector3 targetPosition = targetObj.transform.position + targetObj.GetComponent<Vehicle>().velocity;

        // Draws a debug line to future position
        Debug.DrawLine(vehiclePosition, targetPosition, Color.green);

        // Call and return seek on the future position of target object
        return Flee(targetPosition);
    }

    // Wander method
    public Vector3 Wander()
    {
        // Projects a circle ahead in the direction of velocity
        Vector3 projectedCircleCenter = vehiclePosition + (direction * 3);

        // Random angle
        float randAngle = Random.Range(0, 360);

        // Find x coordinate of projected circle at the random angle
        float xCoord = projectedCircleCenter.x + Mathf.Cos(Mathf.Deg2Rad * randAngle);

        // Find z coordinate of projected circle at the random angle
        float zCoord = projectedCircleCenter.z + Mathf.Sin(Mathf.Deg2Rad * randAngle);

        return Seek(new Vector3(xCoord, 0, zCoord)) * 10;
    }
}
