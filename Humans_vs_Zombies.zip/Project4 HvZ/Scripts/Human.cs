﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Human : Vehicle
{
    public List<GameObject> listOfZombies;
    public GameObject psg;

    // Start is called before the first frame update
    void Start()
    {
        base.Start();

        listOfZombies = GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfZombies;
        psg = GameObject.Find("PSG");
    }

    // Update is called once per frame
    void Update()
    {
        base.Update();

        // Teleports the psg once the human gets too close
        if (Vector3.Distance(vehiclePosition, psg.transform.position) < 1.75f)
        {
            GameObject.Find("SceneManager").GetComponent<SceneManager>().suppliesCollected++;
            psg.transform.position = new Vector3(Random.Range(-18, 18), 0, Random.Range(-18, 18));
        }
    }

    public override void CalcSteeringForces()
    {
        Vector3 ultimateForce = Vector3.zero;
        
        if (Vector3.Distance(new Vector3(0, 0.55f, 0), vehiclePosition) > 18)
        {
            // Calls seek on center if vehicle is a certain distance away to enforce boundaries 
            // (seek center force multiplied by distance. Distance is divided by an appropriate number to ensure reasonable balance of forces)
            ultimateForce += Seek(new Vector3(0, 0.55f, 0)) * (Vector3.Distance(vehiclePosition, new Vector3(0, 0.55f, 0)) / 45);
        }

        // Calls seek (instead of pursue because psg has no velocity) on psg always
        ultimateForce += Seek(psg) * 1.25f;

        // Calls wander if there is nothing to seek
        if (psg == null)
        {
            ultimateForce += Wander();
        }

        // Determines if any of the zombies are close to enough to evade from and calls evade from them
        for (int i = 0; i < listOfZombies.Count; i++)
        {
            float dist = Vector3.Distance(vehiclePosition, listOfZombies[i].GetComponent<Zombie>().vehiclePosition);
            if (dist < 5)
            {
                ultimateForce += Evade(listOfZombies[i]) * 1.25f;
            }
        }

        // Calls obstacle avoidance
        for (int i = 0; i < GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfObstacles.Count; i++)
            ultimateForce += ObstacleAvoidance(GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfObstacles);

        // Calls seperation
        ultimateForce += Seperation(GameObject.Find("SceneManager").GetComponent<SceneManager>().listOfHumans, 2);

        ultimateForce.Normalize();

        // Scales ultimate force by max speed
        ultimateForce *= maxSpeed;

        // Applies ultimate force
        ApplyForce(ultimateForce);
    }

    // Debug Lines method
    void OnRenderObject()
    {
        if (GameObject.Find("SceneManager").GetComponent<SceneManager>().debugLinesToggle)
        {
            // Sets Material for forward vector line
            greenMat.SetPass(0);

            // Begins drawing lines
            GL.Begin(GL.LINES);

            // Starting point
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));

            // End point
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + transform.forward);

            // Ends draw
            GL.End();

            // Sets Material for right vector line
            blueMat.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + transform.right);
            GL.End();

            // Sets material for future position line
            purpleMat.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z));
            GL.Vertex(new Vector3(transform.position.x, 2.5f, transform.position.z) + (velocity * 2));
            GL.End();
        }
    }
}
